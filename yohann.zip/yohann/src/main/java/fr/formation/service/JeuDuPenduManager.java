package fr.formation.service;

import fr.formation.model.JeuPendu;

public interface JeuDuPenduManager {
	public boolean jouerUneLettre(char c, JeuPendu jp);

}
